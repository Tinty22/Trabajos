package FigurasGeométricas;

public abstract class FigurasGeométricas {

	String nombre;
	int cantLados, cantAngulos, medidaLados; 
	
	public FigurasGeométricas(String n, int cL, int cA, int m) {
		this.nombre = n;
		this.cantLados = cL;
		this.cantAngulos = cA;
		this.medidaLados = m;
		
		
	}
	
	
	
	}


