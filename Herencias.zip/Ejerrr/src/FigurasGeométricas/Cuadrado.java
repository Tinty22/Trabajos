package FigurasGeométricas;

public class Cuadrado extends FigurasGeométricas {

	
	int gradosAngulos, area, perimetro;

	
	public Cuadrado(String n, int cL, int cA, int m, int ar, int per) {
		super(n,cL,cA,m);
		this.area = ar;
		this.perimetro = per;
		
	}
	
	}


