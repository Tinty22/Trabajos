package FigurasGeométricas;

public class Trangulo extends FigurasGeométricas {
	
	

	String tipo;
	int gradosAngulos, area, altura, perimetro;
	
	public Trangulo (String n, int cL, int cA, int m, String t, int gA, int ar, int al, int per) {
		super(n,cL,cA,m);
		this.tipo = t;
		this.altura = al;
		this.altura = ar;
		this.perimetro = per;
		
	}
	

}
