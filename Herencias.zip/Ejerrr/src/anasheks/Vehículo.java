package anasheks;

public abstract class Vehículo {

	String matricula, seguro;
	int duenos;
	
	
	
	
	public Vehículo(String m, int d,String se ) {
		this.seguro = se;
		this.matricula = m;
		this.duenos = d;
		
	}





		


	}
