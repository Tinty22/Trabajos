package anasheks;

public class moto extends Vehículo{

	
		String fechCompra, marca, cilindrado;
		int kilometros;
		

		
		public moto(String m, int d,String se, String C, int k, String c, String M) {
			super(m,d,se);
			this.fechCompra = C;
			this.kilometros = k;
			this.cilindrado = c;
			this.marca = M;
		}
		
		
	

}
