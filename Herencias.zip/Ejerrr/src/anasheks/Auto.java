package anasheks;

public class Auto extends  Vehículo{

	String fechCompra, marca;
	int numPuertas, kilometros;
	
	
	public Auto(String m, int d,String se, String C, int P, int k, String M) {
		super(m,d,se);
		this.fechCompra = C;
		this.numPuertas = P;
		this.kilometros = k;
		this.marca = M;
		
		
	}
	
	
}

