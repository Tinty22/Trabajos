package Personas;

public class Profesor extends Personas {

	String cursos, materias, grados, horarios;
	int alumnos;

	public Profesor(String nc, int CI, String fN, String c, String m, String g, String h, int a) {
		super(nc, CI, fN);
		this.cursos = c;
		this.materias = m;
		this.grados = g;
		this.horarios = h;
		this.alumnos = a;
		
	}

}
