package Personas;

public abstract class Personas {

	String nombreCompleto, fechNacimiento;
	int CI;
	
	
	
	
	public Personas(String nc, int CI, String fN) {
		this.nombreCompleto = nc;
		this.CI = CI;
		this.fechNacimiento = fN;
		
		
	




	}

}
