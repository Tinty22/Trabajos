package Personas;

public class Estudiante extends Personas {

	
	String curso, orientacion, materias, horarios;
	int nroSalon;
	
	public Estudiante (String nc, int CI, String fN, String c, String o, String m, int nS, String h) {
		super(nc,CI,fN);
		this.curso = c;
		this.orientacion = o;
		this.materias = m;
		this.nroSalon = nS;
		this.horarios = h;
	}
	
	

	}


